"use strict";
(() => {
  // src/popup.js
  var AI_GATEWAY_URL = "https://ai-gateway.tiltcheck.me";
  var TRUSTED_AI_DOMAINS = [
    "ai-gateway.tiltcheck.me",
    "api.tiltcheck.me",
    "localhost"
  ];
  function isValidAIGatewayURL(url) {
    try {
      const parsedUrl = new URL(url);
      return TRUSTED_AI_DOMAINS.includes(parsedUrl.hostname);
    } catch {
      return false;
    }
  }
  var currentSessionId = null;
  var updateInterval = null;
  var isMonitoring = false;
  var licenseIcon = document.getElementById("licenseIcon");
  var licenseTitle = document.getElementById("licenseTitle");
  var licenseDetails = document.getElementById("licenseDetails");
  var licenseWarning = document.getElementById("licenseWarning");
  var tiltSection = document.getElementById("tiltSection");
  var tiltScore = document.getElementById("tiltScore");
  var tiltIndicators = document.getElementById("tiltIndicators");
  var interventionBox = document.getElementById("interventionBox");
  var interventionIcon = document.getElementById("interventionIcon");
  var interventionMessage = document.getElementById("interventionMessage");
  var interventionPrimary = document.getElementById("interventionPrimary");
  var interventionSecondary = document.getElementById("interventionSecondary");
  var sessionStats = document.getElementById("sessionStats");
  var statDuration = document.getElementById("statDuration");
  var statBets = document.getElementById("statBets");
  var statProfit = document.getElementById("statProfit");
  var statROI = document.getElementById("statROI");
  var statRTP = document.getElementById("statRTP");
  var statVerdict = document.getElementById("statVerdict");
  var startBtn = document.getElementById("startBtn");
  var stopBtn = document.getElementById("stopBtn");
  var vaultBtn = document.getElementById("vaultBtn");
  var reportBtn = document.getElementById("reportBtn");
  function sendMessage(message) {
    return new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, message, (response) => {
            resolve(response || { error: "No response" });
          });
        } else {
          resolve({ error: "No active tab" });
        }
      });
    });
  }
  async function callAIGateway(application, data) {
    const gatewayUrl = `${AI_GATEWAY_URL}/api/ai`;
    if (!isValidAIGatewayURL(gatewayUrl)) {
      console.error("[TiltGuard] Untrusted AI Gateway URL blocked");
      return { success: false, error: "Untrusted AI Gateway URL" };
    }
    try {
      const response = await fetch(gatewayUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          application,
          prompt: data.prompt || "",
          context: data.context || {}
        })
      });
      if (response.ok) {
        return await response.json();
      }
      return { success: false, error: "AI Gateway request failed" };
    } catch (error) {
      console.log("[TiltGuard] AI Gateway offline, using local analysis");
      return { success: false, error: error.message };
    }
  }
  function updateLicenseDisplay(verification) {
    if (!verification) {
      licenseIcon.textContent = "\u{1F50D}";
      licenseTitle.textContent = "Checking license...";
      licenseDetails.textContent = "-";
      return;
    }
    if (verification.isLegitimate) {
      licenseIcon.textContent = "\u2705";
      licenseTitle.textContent = "Licensed Casino";
      licenseDetails.textContent = verification.licenseInfo?.authority || "Verified";
      licenseWarning.classList.add("hidden");
    } else {
      licenseIcon.textContent = "\u26A0\uFE0F";
      licenseTitle.textContent = verification.verdict || "Unlicensed";
      licenseDetails.textContent = "Proceed with caution";
      licenseWarning.textContent = `\u26A0\uFE0F ${verification.reasoning || "This casino may not be properly licensed"}`;
      licenseWarning.classList.remove("hidden");
    }
  }
  async function updateTiltDisplay(tiltData) {
    if (!tiltData) return;
    tiltSection.classList.remove("hidden");
    const score = tiltData.tiltRisk || tiltData.tiltScore || 0;
    tiltScore.textContent = `${Math.round(score)}/100`;
    tiltScore.className = "tilt-score";
    if (score >= 60) {
      tiltScore.classList.add("danger");
    } else if (score >= 30) {
      tiltScore.classList.add("warning");
    }
    const aiResult = await callAIGateway("tilt-detection", {
      context: {
        recentBets: tiltData.recentBets || [],
        sessionDuration: tiltData.sessionDuration || 0,
        losses: tiltData.losses || 0
      }
    });
    const indicators = aiResult.success ? aiResult.data.indicators : (tiltData.tiltSigns || []).map((s) => s.message || s);
    tiltIndicators.innerHTML = indicators.map((indicator) => {
      const severity = indicator.toLowerCase().includes("critical") ? "critical" : indicator.toLowerCase().includes("high") ? "high" : indicator.toLowerCase().includes("medium") ? "medium" : "low";
      return `
      <div class="tilt-indicator ${severity}">
        <div class="tilt-indicator-title">${indicator}</div>
      </div>
    `;
    }).join("");
    if (aiResult.success && aiResult.data.cooldownRecommended) {
      showIntervention({
        type: "cooldown",
        message: aiResult.data.interventionSuggestions?.[0] || "Consider taking a break",
        duration: aiResult.data.cooldownDuration || 300
      });
    }
  }
  function showIntervention(intervention) {
    interventionBox.classList.remove("hidden");
    if (intervention.type === "cooldown" || intervention.severity === "critical") {
      interventionBox.classList.add("critical");
      interventionIcon.textContent = "\u{1F6D1}";
    } else {
      interventionBox.classList.remove("critical");
      interventionIcon.textContent = "\u26A0\uFE0F";
    }
    interventionMessage.textContent = intervention.message;
    interventionPrimary.textContent = intervention.primaryAction || "Take Break";
    interventionPrimary.onclick = () => {
      sendMessage({ type: "start_cooldown", duration: intervention.duration || 3e5 });
      interventionBox.classList.add("hidden");
    };
    interventionSecondary.textContent = "Dismiss";
    interventionSecondary.onclick = () => {
      interventionBox.classList.add("hidden");
    };
  }
  function updateSessionStats(stats) {
    if (!stats) return;
    sessionStats.classList.remove("hidden");
    const duration = stats.duration || Math.floor((Date.now() - stats.startTime) / 1e3);
    const minutes = Math.floor(duration / 60);
    statDuration.textContent = `${minutes}m`;
    statBets.textContent = stats.totalBets || 0;
    const profit = (stats.totalWon || 0) - (stats.totalWagered || 0);
    statProfit.textContent = `$${profit.toFixed(2)}`;
    statProfit.className = "stat-value " + (profit >= 0 ? "" : "negative");
    const roi = stats.totalWagered > 0 ? (profit / stats.totalWagered * 100).toFixed(1) : 0;
    statROI.textContent = `${roi}%`;
    statROI.className = "stat-value " + (roi >= 0 ? "" : "negative");
    const rtp = stats.totalWagered > 0 ? (stats.totalWon / stats.totalWagered * 100).toFixed(1) : 0;
    statRTP.textContent = `${rtp}%`;
    if (rtp < 90) {
      statVerdict.textContent = "COLD";
      statVerdict.className = "stat-value negative";
    } else if (rtp > 100) {
      statVerdict.textContent = "HOT";
      statVerdict.className = "stat-value";
    } else {
      statVerdict.textContent = "NORMAL";
      statVerdict.className = "stat-value neutral";
    }
  }
  async function startGuardian() {
    const result = await sendMessage({ type: "start_analysis" });
    if (result.success || !result.error) {
      isMonitoring = true;
      currentSessionId = result.sessionId || `session_${Date.now()}`;
      startBtn.classList.add("hidden");
      stopBtn.classList.remove("hidden");
      updateInterval = setInterval(refreshStatus, 3e3);
      await refreshStatus();
    } else {
      alert("Failed to start: " + (result.error || "Unknown error"));
    }
  }
  async function stopGuardian() {
    const result = await sendMessage({ type: "stop_analysis" });
    isMonitoring = false;
    currentSessionId = null;
    startBtn.classList.remove("hidden");
    stopBtn.classList.add("hidden");
    if (updateInterval) {
      clearInterval(updateInterval);
      updateInterval = null;
    }
    tiltSection.classList.add("hidden");
    interventionBox.classList.add("hidden");
  }
  async function refreshStatus() {
    const licenseResult = await sendMessage({ type: "get_license_verification" });
    if (licenseResult && !licenseResult.error) {
      updateLicenseDisplay(licenseResult);
    }
    const tiltResult = await sendMessage({ type: "get_tilt_status" });
    if (tiltResult && !tiltResult.error) {
      await updateTiltDisplay(tiltResult);
    }
    const statsResult = await sendMessage({ type: "get_session_stats" });
    if (statsResult && !statsResult.error) {
      updateSessionStats(statsResult);
    }
    const interventionResult = await sendMessage({ type: "get_pending_intervention" });
    if (interventionResult && interventionResult.intervention) {
      showIntervention(interventionResult.intervention);
    }
  }
  function openVault() {
    chrome.tabs.create({ url: "https://tiltcheck.me/vault" });
  }
  async function viewFullReport() {
    const result = await sendMessage({ type: "request_report" });
    if (result.error) {
      alert("Failed to get report: " + result.error);
      return;
    }
    const reportData = JSON.stringify(result.report, null, 2);
    const blob = new Blob([reportData], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    chrome.tabs.create({ url });
  }
  if (startBtn) startBtn.addEventListener("click", startGuardian);
  if (stopBtn) stopBtn.addEventListener("click", stopGuardian);
  if (vaultBtn) vaultBtn.addEventListener("click", openVault);
  if (reportBtn) reportBtn.addEventListener("click", viewFullReport);
  refreshStatus();
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
      case "license_verification":
        updateLicenseDisplay(message.data);
        break;
      case "tilt_update":
        updateTiltDisplay(message.data);
        break;
      case "intervention":
        showIntervention(message.data);
        break;
      case "session_stats":
        updateSessionStats(message.data);
        break;
    }
    sendResponse({ received: true });
    return true;
  });
})();
//# sourceMappingURL=popup.js.map
