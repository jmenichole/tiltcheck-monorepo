"use strict";
(() => {
  // src/popup.js
  var currentSessionId = null;
  var updateInterval = null;
  var statusDot = document.getElementById("statusDot");
  var statusText = document.getElementById("statusText");
  var casinoId = document.getElementById("casinoId");
  var gameId = document.getElementById("gameId");
  var startBtn = document.getElementById("startBtn");
  var stopBtn = document.getElementById("stopBtn");
  var reportBtn = document.getElementById("reportBtn");
  var statsSection = document.getElementById("statsSection");
  var totalSpins = document.getElementById("totalSpins");
  var totalWagered = document.getElementById("totalWagered");
  var totalWon = document.getElementById("totalWon");
  var rtp = document.getElementById("rtp");
  var verdict = document.getElementById("verdict");
  var autoStartToggle = document.getElementById("autoStartToggle");
  function sendMessage(message) {
    return new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, message, (response) => {
            resolve(response || { error: "No response" });
          });
        } else {
          resolve({ error: "No active tab" });
        }
      });
    });
  }
  async function updateStatus() {
    const status = await sendMessage({ type: "get_status" });
    if (status.error) {
      statusText.textContent = "Not on casino site";
      statusDot.classList.remove("active");
      return;
    }
    if (status.isActive) {
      statusText.textContent = "Analyzing...";
      statusDot.classList.add("active");
      startBtn.classList.add("hidden");
      stopBtn.classList.remove("hidden");
      reportBtn.disabled = false;
      statsSection.classList.remove("hidden");
      currentSessionId = status.sessionId;
    } else {
      statusText.textContent = "Ready";
      statusDot.classList.remove("active");
      startBtn.classList.remove("hidden");
      stopBtn.classList.add("hidden");
      reportBtn.disabled = true;
      statsSection.classList.add("hidden");
      currentSessionId = null;
    }
    casinoId.textContent = status.casinoId || "-";
    gameId.textContent = status.gameId || "-";
  }
  async function startAnalysis() {
    const result = await sendMessage({ type: "start_analysis" });
    if (result.success) {
      await updateStatus();
      startStatsUpdate();
    } else {
      alert("Failed to start analysis: " + (result.error || "Unknown error"));
    }
  }
  async function stopAnalysis() {
    const result = await sendMessage({ type: "stop_analysis" });
    if (result.success) {
      await updateStatus();
      stopStatsUpdate();
    }
  }
  async function viewReport() {
    const result = await sendMessage({ type: "request_report" });
    if (result.error) {
      alert("Failed to get report: " + result.error);
      return;
    }
    const report = result.report;
    if (report.sessionStats) {
      totalSpins.textContent = report.sessionStats.totalSpins || 0;
      totalWagered.textContent = `$${(report.sessionStats.totalWagered || 0).toFixed(2)}`;
      totalWon.textContent = `$${(report.sessionStats.totalWon || 0).toFixed(2)}`;
      rtp.textContent = `${(report.sessionStats.actualRTP || 0).toFixed(2)}%`;
      const rtpValue = report.sessionStats.actualRTP || 0;
      if (rtpValue < 90) {
        rtp.classList.add("danger");
        rtp.classList.remove("warning");
      } else if (rtpValue < 95) {
        rtp.classList.add("warning");
        rtp.classList.remove("danger");
      } else {
        rtp.classList.remove("danger", "warning");
      }
    }
    if (report.verdict) {
      verdict.textContent = report.verdict.toUpperCase();
      verdict.className = "stat-value";
      if (report.verdict === "rigged" || report.verdict === "unfair") {
        verdict.classList.add("danger");
      } else if (report.verdict === "suspicious") {
        verdict.classList.add("warning");
      }
    }
    if (report.recommendations && report.recommendations.length > 0) {
      alert("Report:\n\n" + report.recommendations.join("\n\n"));
    }
  }
  function startStatsUpdate() {
    if (updateInterval)
      clearInterval(updateInterval);
    updateInterval = setInterval(async () => {
      if (currentSessionId) {
        await viewReport();
      }
    }, 5e3);
  }
  function stopStatsUpdate() {
    if (updateInterval) {
      clearInterval(updateInterval);
      updateInterval = null;
    }
  }
  function toggleAutoStart() {
    const enabled = autoStartToggle.checked;
    chrome.storage.local.set({ autoStart: enabled });
  }
  startBtn.addEventListener("click", startAnalysis);
  stopBtn.addEventListener("click", stopAnalysis);
  reportBtn.addEventListener("click", viewReport);
  autoStartToggle.addEventListener("change", toggleAutoStart);
  chrome.storage.local.get(["autoStart"], (result) => {
    autoStartToggle.checked = result.autoStart || false;
  });
  updateStatus();
  setInterval(updateStatus, 2e3);
})();
//# sourceMappingURL=popup.js.map
