╔══════════════════════════════════════════════════════════════╗
║  🎰 TiltGuard Extension - Quick Reference                   ║
╚══════════════════════════════════════════════════════════════╝

┌─────────────────────────────────────────────────────────────┐
│ 🚀 START SERVER                                             │
└─────────────────────────────────────────────────────────────┘

  cd browser-extension
  nohup node server/api.js > server.log 2>&1 &
  
  ✓ Server runs at: http://localhost:3333


┌─────────────────────────────────────────────────────────────┐
│ 🔨 BUILD EXTENSION                                          │
└─────────────────────────────────────────────────────────────┘

  cd browser-extension
  pnpm build
  
  ✓ Extension built in: ./dist/


┌─────────────────────────────────────────────────────────────┐
│ 🔌 LOAD IN CHROME                                           │
└─────────────────────────────────────────────────────────────┘

  1. chrome://extensions/
  2. Toggle "Developer mode" ON
  3. Click "Load unpacked"
  4. Select: browser-extension/dist


┌─────────────────────────────────────────────────────────────┐
│ 🧪 TEST EXTENSION                                           │
└─────────────────────────────────────────────────────────────┘

  1. Visit: stake.com (or any casino site)
  2. See TiltGuard sidebar on right
  3. Click "Continue as Guest"
  4. Click "📊 Dashboard" → See stats popup
  5. Click "🔒 Vault" → See vault data
  6. Click "💰 Wallet" → See wallet info
  7. Click "Vault Current Balance" → Deposit to vault


┌─────────────────────────────────────────────────────────────┐
│ 🔍 TEST API                                                 │
└─────────────────────────────────────────────────────────────┘

  # Health check
  curl http://localhost:3333/api/health
  
  # Premium plans
  curl http://localhost:3333/api/premium/plans
  
  # Create guest user
  curl -X POST http://localhost:3333/api/auth/guest \
    -H "Content-Type: application/json" \
    -d '{"username":"TestUser"}'


┌─────────────────────────────────────────────────────────────┐
│ 📊 MONITOR SERVER                                           │
└─────────────────────────────────────────────────────────────┘

  # Watch logs
  tail -f browser-extension/server.log
  
  # Check status
  curl http://localhost:3333/api/health
  
  # Kill server
  lsof -ti:3333 | xargs kill -9


┌─────────────────────────────────────────────────────────────┐
│ 🔄 RELOAD EXTENSION                                         │
└─────────────────────────────────────────────────────────────┘

  After code changes:
  1. pnpm build
  2. chrome://extensions/
  3. Click ↻ on TiltGuard card
  
  OR for clean reload:
  1. Remove extension
  2. rm -rf dist
  3. pnpm build
  4. Re-add extension


┌─────────────────────────────────────────────────────────────┐
│ ✅ WHAT WORKS NOW                                           │
└─────────────────────────────────────────────────────────────┘

  ✓ Backend API server (localhost:3333)
  ✓ Guest authentication
  ✓ Discord auth (demo)
  ✓ Dashboard popup with live data
  ✓ Vault deposits & balance tracking
  ✓ Wallet display
  ✓ Premium tier upgrades
  ✓ Session export
  ✓ License verification
  ✓ Real-time sidebar updates


┌─────────────────────────────────────────────────────────────┐
│ 📚 DOCUMENTATION                                            │
└─────────────────────────────────────────────────────────────┘

  SETUP_COMPLETE.md    - Overview & setup summary
  API_INTEGRATION.md   - Complete API reference
  BACKEND_TESTING.md   - Testing checklist
  QUICK_REFERENCE.md   - This file


┌─────────────────────────────────────────────────────────────┐
│ 🐛 TROUBLESHOOTING                                          │
└─────────────────────────────────────────────────────────────┘

  Server not responding?
  → Check: curl http://localhost:3333/api/health
  → Restart: nohup node server/api.js > server.log 2>&1 &
  
  Buttons not working?
  → Rebuild: pnpm build
  → Reload extension in Chrome
  → Check console: F12 → Console tab
  
  Port 3333 in use?
  → Kill: lsof -ti:3333 | xargs kill -9
  → Restart server


┌─────────────────────────────────────────────────────────────┐
│ 🎯 API ENDPOINTS                                            │
└─────────────────────────────────────────────────────────────┘

  POST   /api/auth/guest           Create guest session
  POST   /api/auth/discord         Discord OAuth (demo)
  GET    /api/auth/me              Get current user
  
  GET    /api/vault/:userId        Get vault info
  POST   /api/vault/:userId/deposit   Deposit to vault
  POST   /api/vault/:userId/withdraw  Withdraw from vault
  
  GET    /api/dashboard/:userId    Get dashboard data
  GET    /api/wallet/:userId       Get wallet info
  
  GET    /api/premium/plans        List premium plans
  POST   /api/premium/upgrade      Upgrade tier
  
  GET    /api/health               Server health check


╔══════════════════════════════════════════════════════════════╗
║  You're all set! Reload the extension and test it out! 🚀   ║
╚══════════════════════════════════════════════════════════════╝
